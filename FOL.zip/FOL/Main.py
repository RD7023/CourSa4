import FOL.Alphabet as Symb
from FOL.Variable import Variable
from FOL.Constant import Constant
from FOL.Function import Function
from FOL.Term import Term
from FOL.AtomicFormulae import AtomicFormulae
from FOL.Formulae import Formulae
from FOL.Sequence import Sequence
import FOL.InferenceCheck as check
x = Variable('x')
y = Variable('y')
z = Variable('z')

a = Constant('a')
b = Constant('b')
c = Constant('c')

f = Function('f', [x, y])
g = Function('g', [z])
h = Function('h', [x, y, z])

f1 = Term('f1', [f, g])
g1 = Term('g1', [f, h, f])

P = AtomicFormulae('P', [f1])
Q = AtomicFormulae('Q', [g1, f1])

F = Formulae([Symb.q_universal, x], [P])
Q = Formulae([], [Q, Symb.l_or, P])
F_imp_Q = Formulae([], [F, Symb.l_implication, Q])

S = Sequence([F, F], [Q, Q, F_imp_Q])
S1 = Sequence([F, F, F], [Q, Q, Q])
S2 = Sequence([Q, F], [Q, Q])
print(check.imp_right(S1, S))
